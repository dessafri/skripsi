<div class="navigation">
    <div class="container">
        <div class="row">
            <div class="col col-10">
                <nav class="navbar navbar-light bg-light">
                    <h1 class="navbar-brand mb-0">
                        SELAMAT DATANG, ADMIN !
                    </h1>
                </nav>
                <span>SISTEM PENGUKURAN KUALITAS BLENDED LEARNING</span>
            </div>
            <div class="col col-2">
                <form method="POST">
                    <button type="submit" name="logout" class="btn btn-danger float-right">Logout</button>
                </form>
            </div>
        </div>
    </div>
</div>